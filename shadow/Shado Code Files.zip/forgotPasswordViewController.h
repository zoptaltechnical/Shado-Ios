//
//  forgotPasswordViewController.h
//  shadow
//
//  Created by Eshan cheema on 12/14/17.
//  Copyright © 2017 Geetika. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface forgotPasswordViewController : UIViewController
{
    IBOutlet UIButton *submitBtn;
    
    IBOutlet UITextField *emailTextFld;
    IBOutlet UIButton *backBtn;
}
@end
