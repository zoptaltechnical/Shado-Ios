//
//  SignUpViewController.h
//  shadow
//
//  Created by Eshan cheema on 12/14/17.
//  Copyright © 2017 Geetika. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpViewController : UIViewController
{
    
    IBOutlet UIImageView *imagePic;
    IBOutlet UIButton *cameraBtn;
    IBOutlet UITextField *nameTxtFld;
    IBOutlet UITextField *emailTxtFld;
    IBOutlet UITextField *phnNumTxtFld;
    IBOutlet UITextField *passwordTxtFld;
    IBOutlet UIButton *signUpbtn;
    IBOutlet UIButton *signUpFacebookBtn;
    IBOutlet UIButton *signInBtn;
}
@end
